﻿using FilmsCatalog.Modules.Core.ViewModels;
using FilmsCatalog.Modules.Films.Extensions;
using FilmsCatalog.Modules.Films.Services;
using FilmsCatalog.Modules.Films.ViewModels;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Diagnostics;
using System.Security.Claims;
using System.Threading.Tasks;

namespace FilmsCatalog.Modules.Films.Controllers
{
    [Authorize]
    public class FilmsController : Controller
    {
        private readonly IFilmService _filmService;
        public FilmsController(IFilmService filmService)
        {
            _filmService = filmService;
        }

        [HttpGet]
        public async Task<IActionResult> Index([FromQuery] int page = 1)
        {
            //Get films
            var result = await _filmService.GetPagedAsync(page);

            return View(result);
        }
        [HttpGet]
        public async Task<IActionResult> Details([FromRoute] Guid id)
        {
            if (id == Guid.Empty)  
                return NotFound();  

            //Get film
            var result = await _filmService.GetById(id);

            if (result == null)  
                return NotFound();  

            return View(result);
        }
        public IActionResult Create()  
        {  
            return View();
        }  
  
        [HttpPost]  
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(FilmCreateViewModel model)  
        {  
            if (ModelState.IsValid)  
            {
                //Get user id
                var userId = HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);
                
                //Check image extension
                if(!model.Image.IsImage())
                    return BadRequest();

                //Create new film
                await _filmService.Create(model, userId);

                return RedirectToAction(nameof(Index));  
            }  
            return View(model);  
        }  
  
        public async Task<IActionResult> Edit(Guid id)  
        {  
            if (id == Guid.Empty)
                return NotFound();  
  
            //Get film
            var result = await _filmService.GetById(id);

            if (result == null)
                return NotFound();

            var model = new FilmUpdateViewModel();

            //Fill model from result
            model.Id = result.Id;
            model.Name = result.Name;
            model.Description = result.Description;
            model.ReleaseYear = result.ReleaseYear;
            model.Director = result.Director;

            return View(model);  
        }  
  
        [HttpPost]  
        [ValidateAntiForgeryToken]  
        public async Task<IActionResult> Edit(FilmUpdateViewModel model)  
        { 
            if (model.Id == Guid.Empty)
                return NotFound(); 

            if (ModelState.IsValid)
            {  
                //Get film
                var result = await _filmService.GetById(model.Id);

                if (result == null)
                    return NotFound();

                //Get user id
                var userId = HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);

                //Updating is allowed only to the user who added the film
                if(result.UserId != userId)
                    return Forbid();
                
                //Check image extension
                if(model.Image != null && !model.Image.IsImage())
                    return BadRequest();
                
                //Update film
                await _filmService.Update(model, userId);

                return RedirectToAction(nameof(Index));  
            }  
            return View();  
        }  
        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
