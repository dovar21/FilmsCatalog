using System;
using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Http;

namespace FilmsCatalog.Modules.Films.ViewModels
{
    public class FilmCreateViewModel
    {
        [Required]
        [StringLength(200)]
        [Display(Name = "Название")]
        public string Name { get; set; }
        [Display(Name = "Описание")]
        public string Description { get; set; }
        [Required]
        [Display(Name = "Год выпуска")]
        public Int16 ReleaseYear { get; set; }
        [Required]
        [StringLength(200)]
        [Display(Name = "Режиссёр")]
        public string Director { get; set; }
        [Required]
        [Display(Name = "Изображение")]
        public IFormFile Image { get; set; }
    }
}
