using System;
using System.ComponentModel.DataAnnotations;

namespace FilmsCatalog.Modules.Films.ViewModels
{
    public class FilmListViewModel
    {
        public Guid Id { get; set; }
        [Display(Name = "Название")]
        public string Name { get; set; }
        [Display(Name = "Описание")]
        public string Description { get; set; }
        [Display(Name = "Год выпуска")]
        public Int16 ReleaseYear { get; set; }
        [Display(Name = "Режиссёр")]
        public string Director { get; set; }
        [Display(Name = "Изображение")]
        public string Image { get; set; }
        [Display(Name = "Пользователь")]
        public string UserName { get; set; }
        public string UserId { get; set; }
    }
}
