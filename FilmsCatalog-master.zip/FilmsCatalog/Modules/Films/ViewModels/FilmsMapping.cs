using AutoMapper;
using FilmsCatalog.Modules.Core.Enums;
using FilmsCatalog.Modules.Core.Repositories;
using FilmsCatalog.Modules.Films.Entities;

namespace FilmsCatalog.Modules.Films.ViewModels
{
    public class FilmsMapping: Profile
    {
        public FilmsMapping()
        {
            CreateMap<Film, FilmListViewModel>()
                .ForMember(vm => vm.UserName, opt => opt.MapFrom(src => src.User.UserName))
                .ForMember(vm => vm.UserId, opt => opt.MapFrom(src => src.User.Id))
                .ForMember(vm => vm.Image, opt => opt.MapFrom(src => $"{FileLocation.RetriveFileFromFolder}/{src.Image}"));
            CreateMap<PaginateResult<Film>, PaginateResult<FilmListViewModel>>();
        }
    }
}
