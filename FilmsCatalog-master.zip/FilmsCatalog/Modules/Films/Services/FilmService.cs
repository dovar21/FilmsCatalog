﻿using System;
using System.IO;
using System.Threading.Tasks;
using AutoMapper;
using FilmsCatalog.Modules.Core.Enums;
using FilmsCatalog.Modules.Core.Repositories;
using FilmsCatalog.Modules.Films.Entities;
using FilmsCatalog.Modules.Films.Repositories;
using FilmsCatalog.Modules.Films.ViewModels;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;

namespace FilmsCatalog.Modules.Films.Services
{
    public class FilmService : IFilmService
    {
        private readonly IFilmRepository _filmRepository;
        private readonly IWebHostEnvironment _webHostEnvironment;
        private readonly IMapper _mapper;

        public FilmService(IFilmRepository filmRepository,
        IMapper mapper,
        IWebHostEnvironment hostEnvironment)
        {
            _filmRepository = filmRepository;
            _mapper = mapper;
            _webHostEnvironment = hostEnvironment;
        }

        public async Task<PaginateResult<FilmListViewModel>> GetPagedAsync(int page)
        {
            //Get films by page
            var films = await _filmRepository.GetPagedAsync(page);

            //Map and return films;
            var result =  this._mapper.Map<PaginateResult<FilmListViewModel>>(films);
            
            return result;
        }

        public async Task<FilmListViewModel> GetById(Guid id)
        {
            //Get film by id
            var result = await _filmRepository.GetByIdAsync(id);
            
            //Map and return film;
            return _mapper.Map<FilmListViewModel>(result);
        }
        public async Task Create(FilmCreateViewModel model, string userId)
        {
            var film = new Film();

            //Fill entity from model
            film.Id = Guid.NewGuid();
            film.Name = model.Name;
            film.Description = model.Description;
            film.ReleaseYear = model.ReleaseYear;
            film.Director = model.Director;
            film.UserId = userId;
            film.Image = UploadedImage(model.Image);

            //Create new film
            await _filmRepository.Create(film);
        }
        public async Task Update(FilmUpdateViewModel model, string userId)
        {
            //Get film by id
            var film = await _filmRepository.GetByIdAsync(model.Id);
            
            //Fill entity from model
            film.Name = model.Name;
            film.Description = model.Description;
            film.ReleaseYear = model.ReleaseYear;
            film.Director = model.Director;
            
            if(model.Image != null)
            {
                var filmImage = $"{FileLocation.FileUploadFolder}/{film.Image}";
                
                //Remove existing image after updating
                if(File.Exists(filmImage))
                    File.Delete(filmImage);

                //Upload image
                film.Image = UploadedImage(model.Image);
            }

            //Update film
            await _filmRepository.Update(film);
        }
        private string UploadedImage(IFormFile image)
        {
            string uniqueFileName = null;

            if (image != null)
            {
                string uploadsFolder = Path.Combine(_webHostEnvironment.WebRootPath,FileLocation.FileUploadFolder);
                
                uniqueFileName = Guid.NewGuid().ToString() + "_" + image.FileName;
                
                string filePath = Path.Combine(uploadsFolder, uniqueFileName);
                
                using (var fileStream = new FileStream(filePath, FileMode.Create))
                {
                    image.CopyTo(fileStream);
                }
            }

            return uniqueFileName;
        }
    }
}

