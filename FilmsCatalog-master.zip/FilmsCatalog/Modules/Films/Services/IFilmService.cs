﻿using System;
using System.Threading.Tasks;
using FilmsCatalog.Modules.Core.Repositories;
using FilmsCatalog.Modules.Films.ViewModels;

namespace FilmsCatalog.Modules.Films.Services
{
    public interface IFilmService
    {
        Task<PaginateResult<FilmListViewModel>> GetPagedAsync(int page);

        Task<FilmListViewModel> GetById(Guid id);
        Task Create(FilmCreateViewModel model, string userId);
        Task Update(FilmUpdateViewModel model, string userId);
    }
}
