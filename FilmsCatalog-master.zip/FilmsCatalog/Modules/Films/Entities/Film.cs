﻿using System;
using FilmsCatalog.Modules.Core.Entities;
using FilmsCatalog.Modules.Identity.Entities;

namespace FilmsCatalog.Modules.Films.Entities
{
    public class Film : BaseEntity
    {
        public string Name { get; set; }
        public string Description { get; set; }
        public Int16 ReleaseYear { get; set; }
        public string Director { get; set; }
        public User User { get; set; }
        public string UserId { get; set; }
        public string Image { get; set; }
    }
}