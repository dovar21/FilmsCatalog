using FilmsCatalog.Modules.Films.Repositories;
using FilmsCatalog.Modules.Films.Services;
using Microsoft.Extensions.DependencyInjection;

namespace FilmsCatalog.Modules.Films.Extensions
{
    public static class ServiceCollectionExtension
    {
        public static IServiceCollection AddFilmServiceCollection(this IServiceCollection serviceCollection)
        {
            serviceCollection.AddTransient<IFilmRepository, FilmRepository>();
            serviceCollection.AddTransient<IFilmService, FilmService>();

            return serviceCollection;
        }
    }
}
