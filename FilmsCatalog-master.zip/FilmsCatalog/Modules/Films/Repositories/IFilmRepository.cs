using System;
using System.Threading.Tasks;
using FilmsCatalog.Modules.Core.Repositories;
using FilmsCatalog.Modules.Films.Entities;

namespace FilmsCatalog.Modules.Films.Repositories
{
    public interface IFilmRepository: IRepositoryBase<Film>
    {
        Task<PaginateResult<Film>> GetPagedAsync(int page);
        Task<Film> GetByIdAsync(Guid id);
    }
}
