using System;
using System.Threading.Tasks;
using FilmsCatalog.Modules.Core;
using FilmsCatalog.Modules.Core.Repositories;
using FilmsCatalog.Modules.Films.Entities;
using Microsoft.EntityFrameworkCore;

namespace FilmsCatalog.Modules.Films.Repositories
{
    public class FilmRepository : RepositoryBase<Film>, IFilmRepository
    {
        public FilmRepository(ApplicationDbContext appDbContext) : base(appDbContext)
        {
        }

       public async Task<PaginateResult<Film>> GetPagedAsync(int page)
        {
            var films = _dbContext.Films.Include(t=>t.User).AsNoTracking();

            Paginate<Film> paging = new Paginate<Film>(films, page);
            
            //return films;
            return await paging.ExecuteAsync();
        }

        public async Task<Film> GetByIdAsync(Guid id)
        {
            //Reurn film by id and include user
            return await _dbContext.Films.Include(t=>t.User).FirstOrDefaultAsync(b =>b.Id == id);
        }
    }
}
