﻿using System.Collections.Generic;
using FilmsCatalog.Modules.Films.Entities;
using Microsoft.AspNetCore.Identity;

namespace FilmsCatalog.Modules.Identity.Entities
{
    public class User : IdentityUser
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string MiddleName { get; set; }
        public ICollection<Film> Films { get; set; }

    }
}