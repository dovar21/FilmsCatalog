namespace FilmsCatalog.Modules.Core.Enums
{
    public static class FileLocation
    {
        public const string FileUploadFolder = "imgs";
        public const string RetriveFileFromFolder = "~/imgs/";
        public const string DeleteFileFromFolder = "wwwroot\\imgs\\";
    }
}