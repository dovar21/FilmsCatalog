using System;
using System.ComponentModel.DataAnnotations;

namespace FilmsCatalog.Modules.Core.Entities
{
    public class BaseEntity
    {
        [Key]
        public Guid Id { get; set; }
    }
}
