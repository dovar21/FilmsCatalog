using System;

namespace FilmsCatalog.Modules.Core.Repositories
{
    public class PaginateParam
    {
        public PaginateParam(int totalItems, int pageNumber, int pageSize)
        {
            this.TotalItems = totalItems;
            this.PageNumber = pageNumber;
            this.PageSize = pageSize;
        }
        public int PageNumber { get; }
        public int TotalPages => (int)Math.Ceiling(this.TotalItems / (double)this.PageSize);
        public int PageSize { get; }
        public int TotalItems { get; }
        public int FirstItem => ((this.PageNumber * this.PageSize) - this.PageSize) + 1;
        public int LastItem => (this.PageNumber * this.PageSize) > this.TotalItems ? this.TotalItems : this.PageNumber * this.PageSize;
        public bool HasPreviousPage => this.PageNumber > 1;
        public bool HasNextPage => this.PageNumber < this.TotalPages;
        public int NextPageNumber => this.HasNextPage ? this.PageNumber + 1 : this.TotalPages;
        public int PreviousPageNumber => this.HasPreviousPage ? this.PageNumber - 1 : 1;
    }
}
