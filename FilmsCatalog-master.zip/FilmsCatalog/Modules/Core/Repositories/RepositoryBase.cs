using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

namespace FilmsCatalog.Modules.Core.Repositories
{
    public abstract class RepositoryBase<T> : IRepositoryBase<T> where T: class
    {
        protected readonly ApplicationDbContext _dbContext;
        public RepositoryBase(ApplicationDbContext appDbContext)
        {
            _dbContext = appDbContext;
        }
        public async Task<IEnumerable<T>> FindAllAsync()
        {
            return await this._dbContext.Set<T>().ToListAsync();
        }
        public async Task<PaginateResult<T>> FindByPaginateAsync(int page=1)
        {
            page = (page == 0) ? 1 : page;

            Paginate<T> paging =  new Paginate<T>(this._dbContext.Set<T>().AsNoTracking(), page);

            var result =  await paging.ExecuteAsync();

            return result;
        }
        public async Task<T> Create(T entity)
        {
            this.ChangeStatusToAdd(entity);

            await this.SaveAsync();

            return entity;
        }
        public async Task Update(T entity)
        {
            this.ChangeStatusToUpdate(entity);

            await this.SaveAsync();
        }
        public async Task SaveAsync()
        {
            await this._dbContext.SaveChangesAsync();            
        }
        protected void ChangeStatusToAdd(T entity)
        {
            this._dbContext.Set<T>().Add(entity);
        }

        protected void ChangeStatusToUpdate(T entity)
        {
            this._dbContext.Set<T>().Update(entity);
        }
    }
}
