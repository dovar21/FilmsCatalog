using System.Collections.Generic;
using System.Threading.Tasks;

namespace FilmsCatalog.Modules.Core.Repositories
{
    public interface IRepositoryBase<T>
    {
        Task<IEnumerable<T>> FindAllAsync();
        Task<PaginateResult<T>> FindByPaginateAsync(int page=1);
        Task<T> Create(T entity);
        Task Update(T entity);
        Task SaveAsync();

    }
}
