using System.Collections.Generic;

namespace FilmsCatalog.Modules.Core.Repositories
{
    public class PaginateResult<T>
    {
        public PaginateResult() { }
        public List<T> List { get; set; }
        public PaginateParam Pagination { get; set; }
    }
}
