using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

namespace FilmsCatalog.Modules.Core.Repositories
{
    public class Paginate<T>
    {
        private int _pageNumber;
        private int _pageSize;
        private IQueryable<T> _query;
        private IList<T> _list;

        public Paginate(IQueryable<T> query, int pageNumber, int pageSize = 10)
        {
            _query = query;
            _pageNumber = pageNumber;
            _pageSize = pageSize;

        }

        public Paginate(IList<T> list, int pageNumber, int pageSize = 10)
        {
            _list = list;
            _pageNumber = pageNumber;
            _pageSize = pageSize;
        }
        
        public async Task<PaginateResult<T>> ExecuteAsync()
        {
            var count = await _query.CountAsync();
            var pagination = new PaginateParam(count, _pageNumber, _pageSize);

            int skip = _pageSize * (_pageNumber - 1);
            var list = await _query.Skip(skip).Take(_pageSize).ToListAsync();
            return new PaginateResult<T>() {Pagination = pagination, List = list};
        }
    }
}
